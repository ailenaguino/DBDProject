package ar.edu.unlam.tallerweb1.servicios;

public interface ServicioOperaciones {

	Double sumar(Double o1, Double o2);
	Double multi(Double o1, Double o2);
	Double rest(Double o1, Double o2);
}
